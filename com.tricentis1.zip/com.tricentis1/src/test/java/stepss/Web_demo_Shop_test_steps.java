package stepss;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Web_demo_Shop_test_steps 
{	
	WebDriver driver;
	Tricentis_pagefactory objdemo;
	XSSFWorkbook wb;
	XSSFSheet sh;
	@Given ("user is on login page")
	public void login_page() throws InterruptedException, IOException
	{


		System.setProperty("webdriver.chrome.driver", "C:\\driver files\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://demowebshop.tricentis.com/");
		Thread.sleep(3000);
		objdemo = new Tricentis_pagefactory(driver);
		objdemo= PageFactory.initElements(driver, Tricentis_pagefactory.class);
		System.out.println("you are in:"+driver.getTitle());
		FileInputStream fread=new FileInputStream("./data sheet/excel_18.xlsx");
		wb=new XSSFWorkbook(fread);
		objdemo.clicklogin();
	}

	@When("user imports data from excel")
	public void User_enter_Username_and_Password() throws InterruptedException 
	{
		sh=wb.getSheet("Sheet1");
		objdemo.loginmail(sh.getRow(2).getCell(0).getStringCellValue());
		objdemo.loginpwd("123456");
		objdemo.loginbutton();
		Thread.sleep(3000);

	}	

	@Then("login should be successful")
	public void login_should_be_successful() 
	{
		System.out.println("Login successfull");
	}

	//New user registration
	@Given("user is on registration page")
	public void registration_page() throws InterruptedException, IOException
	{


		System.setProperty("webdriver.chrome.driver", "C:\\driver files\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://demowebshop.tricentis.com/");
		Thread.sleep(3000);
		objdemo = new Tricentis_pagefactory(driver);
		objdemo= PageFactory.initElements(driver, Tricentis_pagefactory.class);
		System.out.println("you are in:"+driver.getTitle());
		FileInputStream fread=new FileInputStream("./data sheet/excel_18.xlsx");
		wb=new XSSFWorkbook(fread);
		objdemo.Register();
		objdemo.snapshot();
	}
	@When("user imports reg data from excel")
	public void enter_personal_details() throws Throwable 
	{
		sh=wb.getSheet("Reg data");
		objdemo.gender();
		objdemo.fname(sh.getRow(2).getCell(0).getStringCellValue());
		objdemo.lname(sh.getRow(2).getCell(1).getStringCellValue());
		objdemo.reg_email(sh.getRow(2).getCell(2).getStringCellValue());
		objdemo.Password(sh.getRow(2).getCell(3).getStringCellValue());
		objdemo.cnfpasswd(sh.getRow(2).getCell(4).getStringCellValue());
		//objdemo.Regbutton();

	}

	@Then("reg should be successful")
	public void registration_is_successful() throws Throwable 
	{
		System.out.println("you are in:"+driver.getTitle());
		objdemo.regPass();
	}
	
	@Given("user navigates to LoginPage")
	public void navigate_login_page() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\driver files\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://demowebshop.tricentis.com/");
		Thread.sleep(3000);
		objdemo = new Tricentis_pagefactory(driver);
		objdemo= PageFactory.initElements(driver, Tricentis_pagefactory.class);
		System.out.println("the user is on:"+driver.getCurrentUrl());
		objdemo.clicklogin();
	}
	
	
	@When("user enters {string} and {string}")
	public void user_enters_rama_k_gmail_com_and_rama(String string,String string1) throws IOException {
		objdemo.loginmail(string);
		objdemo.loginpwd(string1);
		objdemo.loginbutton();
		//objdemo.snapshot();
	    
	    
	}
	
	@Then("display login_fail alert message")
	public void login_should_fail() throws IOException 
	{
		System.out.println("Login failed.Please enter valid details");
		objdemo.snapshot();
	}


}