package stepss;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Tricentis_pagefactory 
{
	WebDriver driver;
	@FindBy(how=How.XPATH,using="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")
    WebElement click_login;
    @FindBy(how=How.XPATH,using="//*[@id=\"Email\"]")
    WebElement Login_email;
    @FindBy(how=How.XPATH,using="//*[@id=\"Password\"]")
    WebElement Login_pwd;
    @FindBy(how=How.XPATH, using="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input") 
    WebElement Login_button;
    @FindBy(how=How.XPATH, using="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div") 
    WebElement login_fail_error;
   
	@FindBy(how=How.XPATH, using="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a") 
    WebElement Register;
	@FindBy(how=How.ID, using="gender-female") 
    WebElement gender;
	@FindBy(how=How.NAME, using="FirstName")
	WebElement fname;
	@FindBy(how=How.XPATH,using="//*[@id=\"LastName\"]")
	WebElement lname;
	@FindBy(how=How.ID, using="Email")
	WebElement Register_email;
	@FindBy(how=How.XPATH, using="//*[@id=\"Password\"]")
    WebElement passwd;
	@FindBy(how=How.XPATH, using="//*[@id=\"ConfirmPassword\"]")
    WebElement cnfpasswd;
	@FindBy(xpath="//*[@id='register-button']")
    WebElement Regbutton;
	@FindBy(how=How.XPATH, using="/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")
    WebElement RegPass;
	public void Register()
	{
	     Register.click();
	}
	public void gender() 
	{
		gender.click();
	}
	public void fname(String firstname) 
	{
		fname.sendKeys(firstname);
	}
	public void lname(String lastname) 
	{
		lname.sendKeys(lastname);
	}
	public void reg_email(String email)
	{
		Register_email.sendKeys(email);
	}
	public void Password(String pwd) 
	{
		passwd.sendKeys(pwd);
	}
	
	public void cnfpasswd(String cnfpwd) 
	{
		cnfpasswd.sendKeys(cnfpwd);
	}
	public void Regbutton() 
	{
		Regbutton.click();
	}
	public void regPass() throws InterruptedException
	{
		Thread.sleep(3000);
		String Registrationisscuccessful = RegPass.getText();
		System.out.println(Registrationisscuccessful);
	}
    public void clicklogin()
    {
    	click_login.click();
    }
    public void loginmail(String email) {
    	
    	Login_email.sendKeys(email);
    }

    public void loginpwd(String password)
    {
    	Login_pwd.sendKeys(password);
    }
    public void loginbutton()
    {
    	Login_button.click();
    }

    public void loginfailError()
    {
    	String entervalidpwd = login_fail_error.getText();
    	System.out.println(entervalidpwd);
    }
	  
		
		
		
		public Tricentis_pagefactory(WebDriver driver) 
		{
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
		public void snapshot() throws IOException {

			TakesScreenshot ts=(TakesScreenshot)driver;

			File source=ts.getScreenshotAs(OutputType.FILE);

			FileUtils.copyFile(source, new File(System.getProperty("usr.dir")+"/Screenshot/"+System.currentTimeMillis()+".png"));

			System.out.println("screenshot is taken");



		}
		

			

}